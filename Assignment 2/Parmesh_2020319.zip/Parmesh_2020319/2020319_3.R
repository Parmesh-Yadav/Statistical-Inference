#QUESTION 3
rm(list=ls())
set.seed(123)

#given

# a new variety of green gram is expected to
# give a yield of 12.0 quintals per hectare.

#The yields ( quintals/hectare) were recorded as
data <- c(14.3, 12.6, 13.7, 10.9, 13.7, 12.0, 11.4, 12.0, 12.6, 13.1)

# (H0: mu = 12) v/s (H1: mu != 12)
mu_null <- 12
# The variety was tested on 10 randomly selected farmers fields.
n <- 10
# sample mean
sample_mean <- mean(data)
# sample_sd
sample_sd <- sd(data)
#  Use the 5 percent level of significance
alpha = 0.05

# t-test

# t-statistic
t_stat <- (sample_mean-mu_null)/(sample_sd/sqrt(n))
# since its one tailed
# critical value for z(alpha = 0.05)
# since this is 2-tailed, we need to use alpha/2
t_criticalval <- (qt(p=alpha/2,df=n-1,lower.tail = FALSE))

# t_stat lies in the acceptance region => fail to reject the null hypothesis

# p-value
p.val <- pt(q=t_stat,df=n-1,lower.tail = FALSE)

# We fail to reject H0.
# H0 is true.
# Claim is true.





