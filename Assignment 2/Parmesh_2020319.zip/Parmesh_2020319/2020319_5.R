#QUESTION 5
rm(list=ls())
set.seed(123)

#given

# test the hypothesis if there is any average change in weight of children

#data
a = c(49, 53, 51, 52, 47, 50, 52, 53)
b = c(52, 55, 52, 53, 50, 54, 54, 53)
#difference of pairs
d = a-b
# (H0: mu_d = 0) v/s (H1: mu_d != 0)
mu_d <- 0
# observed in 8 children
n <- 8
# sample mean 
sample_mean_d <- mean(d)
# sample_sd
sample_sd_d <- sd(d)
#  Use the 5 percent level of significance
alpha = 0.05

# t-test

# t-statistic
t_stat <- (sample_mean_d-mu_d)/(sample_sd_d/sqrt(n))
# since its one tailed
# critical value for z(alpha = 0.05)
# since this is 2-tailed, we need to use alpha/2
t_criticalval <- (qt(p=alpha/2,df=n-1,lower.tail = TRUE))

# t_stat lies in the rejection region => reject the null hypothesis

# p-value
p.val <- pt(q=t_stat,df=n-1,lower.tail = TRUE)

# p-value < alpha => Reject the null hypothesis

# We reject H0.
# H0 is false.
# Therefore, there is average change weights.





