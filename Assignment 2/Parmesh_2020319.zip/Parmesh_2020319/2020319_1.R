#QUESTION 1
rm(list=ls())
set.seed(123)

#given

# (H0: mu <= 15cm) v/s (H1: mu > 15cm)
mu_null <- 15
# Bakes 10 loafs of bread.
n <- 10
# mean height of the sample loaves is 17 cm
sample_mean <- 17
# standard deviation for the height is 0.5cm
pop_sd <- 0.5
#  Use the 5 percent level of significance
alpha = 0.05

# z-test

# z-statistic
z_stat <- (sample_mean-mu_null)/(pop_sd/sqrt(n))
# since its one tailed
# critical value for z(alpha = 0.05)
z_criticalval <- (qnorm(alpha,mean=0,sd=1,lower.tail = FALSE))

# z_stat lies in the rejection region => reject the null hypothesis

# p-value
p.val <- pnorm(z_stat,mean=0,sd=1,lower.tail = FALSE)

# p-value < alpha => Reject the null hypothesis

# We reject H0.
# H1 is true.
# Claim is true.





