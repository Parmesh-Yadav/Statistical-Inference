#QUESTION 4
rm(list=ls())
set.seed(123)

#given

# The average amount of time boys and girls ages 7 through 11 spend
# playing sports each day is believed to be the same.

# (H0: mu_1 = mu_2) v/s (H1: mu_1 != mu_2)
mu_1 <- 0
mu_2 <- 0
# sample size
n1 <- 9
n2 <- 16
# sample mean 
sample_mean_1 <- 2
sample_mean_2 <- 3.2
# sample_sd
sample_sd_1 <- sqrt(0.75)
sample_sd_2 <- 1
#  Use the 5 percent level of significance
alpha = 0.05

# t-test

# t-statistic
t_stat <- ((sample_mean_1 - sample_mean_2)-(mu_1 - mu_2))/sqrt((sample_sd_1^2/n1)+(sample_sd_2^2/n2))
# since its one tailed
# critical value for z(alpha = 0.05)
# since this is 2-tailed, we need to use alpha/2
t_criticalval <- (qt(p=alpha/2,df=min(n1-1,n2-1),lower.tail = TRUE))

# t_stat lies in the rejection region => reject the null hypothesis

# p-value
p.val <- pt(q=t_stat,df=min(n1-1,n2-1),lower.tail = TRUE)

# p-value < alpha => Reject the null hypothesis

# We reject H0.
# H0 is false.
# Claim is false.





