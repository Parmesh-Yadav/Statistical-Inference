#QUESTION 2
rm(list=ls())
set.seed(123)

#given

# Conduct a hypothesis test to determine if the population mean time on death row
# could likely be 15 years.

# (H0: mu = 15) v/s (H1: mu != 15)
mu_null <- 15
#  A random survey of 75 death row inmates
n <- 75
# revealed that the mean length of time on death row is 17.4 years
sample_mean <- 17.4
# with a sample standard deviation of 6.3 years
sample_sd <- 6.3
#  Use the 5 percent level of significance
alpha = 0.05

# t-test

# t-statistic
t_stat <- (sample_mean-mu_null)/(sample_sd/sqrt(n))
# since its one tailed
# critical value for z(alpha = 0.05)
# since this is 2-tailed, we need to use alpha/2
t_criticalval <- (qt(p=alpha/2,df=n-1,lower.tail = FALSE))

# t_stat lies in the rejection region => reject the null hypothesis

# p-value
p.val <- pt(q=t_stat,df=n-1,lower.tail = FALSE)

# p-value < alpha => Reject the null hypothesis

# We reject H0.
# H0 is false
# Claim is false.





